<footer>
    <div class="footer-content">
        <div class="footer-section">
            <div class="section">
                <ul>
                    <li class="section-heading">ABOUT US</li>
                    <li><a href="/Web_Application/about-us/our_story.php">Our Brand</a></li>
                    <li><a href="/Web_Application/about-us/question.php">FAQs</a></li>
                    <li><a href="/Web_Application/about-us/contact_us.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="section">
                <ul>
                    <li class="section-heading">HELP</li>
                    <li><a href="/Web_Application/about-us/term_condition.php">Terms & Conditions</a></li>
                </ul>
            </div>
            <div class="section">
                <ul>
                    <li class="section-heading">FOLLOW US</li>
                    <li class="footer-icons">
                        <i class="ri-facebook-circle-fill"></i>
                        <i class="ri-youtube-fill"></i>
                        <i class="ri-instagram-line"></i>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <p class="copyright">&copy; 2025 TUB Concept Store. All rights reserved</p>
</footer>